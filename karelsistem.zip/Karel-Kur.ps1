# Karel Santral - TEK DOSYA KURULUM
# GitHub'dan karelsistem.zip indirir, C:\KarelSistem'e cikarir, kurar ve baslatir.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }

# ---------------- AYARLAR ----------------
$ZipUrl = 'https://raw.githubusercontent.com/kendineselam/karel/main/karelsistem.zip'
$Target = 'C:\KarelSistem'
# -----------------------------------------

$tmp = Join-Path $env:TEMP 'karel_kur'
$zip = Join-Path $tmp 'karelsistem.zip'
$ex  = Join-Path $tmp 'x'

function Step($m) { Write-Host "[Karel] $m" -ForegroundColor Cyan }

try {
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Force -Path $ex | Out-Null

  $have = Test-Path (Join-Path $Target 'kur.ps1')
  try {
    Step 'Program GitHub''dan indiriliyor...'
    $url = $ZipUrl + '?t=' + [guid]::NewGuid().ToString('N')
    $curl = Join-Path $env:SystemRoot 'System32\curl.exe'
    if (Test-Path $curl) {
      & $curl -L --fail --retry 3 --connect-timeout 20 -o $zip $url
      if ($LASTEXITCODE -ne 0) { throw "curl hata kodu $LASTEXITCODE" }
    } else {
      Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
    }

    Step 'Dosyalar aciliyor...'
    $tar = Join-Path $env:SystemRoot 'System32\tar.exe'
    $done = $false
    if (Test-Path $tar) { & $tar -xf $zip -C $ex; if ($LASTEXITCODE -eq 0) { $done = $true } }
    if (-not $done) { Expand-Archive -Path $zip -DestinationPath $ex -Force }
    if (-not (Test-Path (Join-Path $ex 'kur.ps1'))) { throw 'Zip icinde kur.ps1 bulunamadi.' }

    New-Item -ItemType Directory -Force -Path $Target | Out-Null
    Copy-Item -Path (Join-Path $ex '*') -Destination $Target -Recurse -Force
    Step "Dosyalar $Target klasorune cikarildi."
  } catch {
    if (-not $have) { throw ('Indirme basarisiz: ' + $_.Exception.Message + ' (github.com acik olmali)') }
    Write-Host ('[Karel] Guncelleme yapilamadi (' + $_.Exception.Message + '), kayitli surumle devam ediliyor.') -ForegroundColor Yellow
  }

  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  Step 'Kurulum / baslatma...'
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Target 'kur.ps1')
  if ($LASTEXITCODE -ne 0) { throw 'kur.ps1 hata verdi. Detay: C:\KarelSistem\kurulum-log.txt' }
}
catch {
  Write-Host ''
  Write-Host ('[HATA] ' + $_.Exception.Message) -ForegroundColor Red
  Read-Host 'Kapatmak icin Enter a bas'
  exit 1
}
