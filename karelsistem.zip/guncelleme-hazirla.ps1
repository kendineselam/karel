# Karel Santral - GitHub'a yuklenecek guncelleme paketini hazirlar
# 1) Program surumunu 1 artirir  2) karelsistem.zip olusturur (electron klasoru ve gereksiz dosyalar HARIC)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

$verFile = Join-Path $root 'app\appversion.txt'
$cur = 0
if (Test-Path $verFile) { [void][int]::TryParse(((Get-Content -Raw $verFile).Trim()), [ref]$cur) }
$new = $cur + 1
[IO.File]::WriteAllText($verFile, [string]$new)
[IO.File]::WriteAllText((Join-Path $root 'appversion.txt'), [string]$new)
Write-Host ("Program surumu: {0} -> {1}" -f $cur, $new)

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$out = Join-Path $root 'karelsistem.zip'
if (Test-Path $out) { Remove-Item $out -Force }

$skipDirs  = @('electron', 'electron_tmp', '_indirme', 'app_yedek', '.git')
$skipFiles = @('karelsistem.zip', 'kurulum-log.txt', 'uygulama-log.txt', 'guncelleme-hazirla.ps1', 'guncelleme-hazirla.bat',
               'appversion.txt', 'manifest.json', 'Karel-Kur.ps1', 'Karel-Kur.bat')

$zip = [IO.Compression.ZipFile]::Open($out, 'Create')
try {
  Get-ChildItem -Path $root -Recurse -File -Force | ForEach-Object {
    $rel = $_.FullName.Substring($root.Length).TrimStart('\', '/')
    $top = ($rel -split '[\\/]')[0]
    if ($skipDirs -contains $top) { return }
    if (($rel -notmatch '[\\/]') -and ($skipFiles -contains $rel)) { return }
    if ($_.Name -eq '.unblocked' -or $_.Extension -eq '.lnk') { return }
    $name = $rel -replace '\\', '/'
    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, $name, [IO.Compression.CompressionLevel]::Optimal)
  }
} finally { $zip.Dispose() }

$mb = [math]::Round((Get-Item $out).Length / 1MB, 2)
Write-Host ''
Write-Host ("HAZIR: karelsistem.zip ({0} MB), program surumu {1}" -f $mb, $new) -ForegroundColor Green
Write-Host ''
Write-Host 'Simdi GitHub (kendineselam/karel, main dali, ana klasor) icine su 2 dosyayi yukle / uzerine yaz:'
Write-Host '   1) karelsistem.zip'
Write-Host ("   2) appversion.txt   (icinde sadece {0} yazar)" -f $new)
Write-Host ''
Write-Host 'Sadece SCRIPT (.user.js) eklediysen / degistirdiysen zip gerekmez:'
Write-Host '   .user.js dosyasini yukle + manifest.json icindeki "version" sayisini artir.'
Write-Host ''
Write-Host 'ONEMLI: yuklemeden once kendi bilgisayarinda calistigini dene!'
