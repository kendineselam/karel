# Karel Santral - kurulum + baslatma (Node.js / npm GEREKTIRMEZ)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$log  = Join-Path $root 'kurulum-log.txt'
$ver  = '45.3.3'
$hashes = @{
  'x64'   = '49dd2d3875944f08de03d34595cd30093c588b9edcabb41a0ac481028a3a5a8a'
  'arm64' = '86a22b905a56566a221dfc225750317e50be326b33d8bf29292bc883b78661e3'
}

if ((Test-Path $log) -and ((Get-Item $log).Length -gt 100KB)) { Remove-Item $log -Force }
function Log([string]$m) {
  Add-Content -Path $log -Value ('{0} {1}' -f (Get-Date -Format 'dd.MM.yyyy HH:mm:ss'), $m)
  Write-Host $m
}
function Fail([string]$m) {
  Log ('HATA: ' + $m)
  Write-Host ''
  Write-Host $m -ForegroundColor Red
  exit 1
}

Log '==== Baslatildi ===='

if ($root -match '\.zip\\') {
  Fail "Klasor zip'in ICINDEN calistiriliyor. Zip'e sag tik > 'Tumunu ayikla' ile bir klasore cikar, sonra oradan calistir."
}

$arch = $env:PROCESSOR_ARCHITEW6432
if (-not $arch) { $arch = $env:PROCESSOR_ARCHITECTURE }
switch ($arch) {
  'AMD64' { $plat = 'x64' }
  'ARM64' { $plat = 'arm64' }
  default { Fail ("Bu Windows desteklenmiyor (islemci: $arch). 64 bit Windows 10/11 gerekir.") }
}

# Dosyalarin "internetten indirildi" isaretini SADECE ilk calistirmada kaldir (her seferinde yapmak acilisi yavaslatiyordu)
$unblockMarker = Join-Path $root 'tools\.unblocked'
if (-not (Test-Path $unblockMarker)) {
  try {
    Get-ChildItem -Path $root -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notlike ($root + '\electron*') } | Unblock-File -ErrorAction SilentlyContinue
    New-Item -ItemType File -Path $unblockMarker -Force | Out-Null
  } catch {}
}

$exe = Join-Path $root 'electron\electron.exe'

function Test-Exe { return ((Test-Path $exe) -and ((Get-Item $exe).Length -gt 1MB)) }

function Get-File([string]$url, [string]$dest) {
  $curl = Join-Path $env:SystemRoot 'System32\curl.exe'
  if (Test-Path $curl) {
    & $curl -L --fail --retry 3 --connect-timeout 20 -o $dest $url
    if ($LASTEXITCODE -ne 0) { throw "curl hata kodu $LASTEXITCODE" }
  } else {
    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing
  }
}

function Install-Electron {
  $name = "electron-v$ver-win32-$plat.zip"
  $want = $hashes[$plat]
  $dl   = Join-Path $root '_indirme'
  New-Item -ItemType Directory -Force -Path $dl | Out-Null
  $zip  = Join-Path $dl $name
  $urls = @(
    "https://github.com/electron/electron/releases/download/v$ver/$name",
    "https://npmmirror.com/mirrors/electron/v$ver/$name"
  )

  Write-Host ''
  Write-Host 'Ilk kurulum: Electron indiriliyor (~110 MB), bir kere yapilir. Pencereyi kapatma.'
  Write-Host ''

  $ok = $false
  foreach ($u in $urls) {
    for ($i = 1; $i -le 2 -and -not $ok; $i++) {
      try {
        Log "Indiriliyor ($i): $u"
        if (Test-Path $zip) { Remove-Item $zip -Force }
        Get-File $u $zip
        $h = (Get-FileHash -Path $zip -Algorithm SHA256).Hash.ToLower()
        if ($h -eq $want) { $ok = $true; Log 'Dosya dogrulandi (SHA256 tamam).' }
        else { Log "SHA256 uyusmadi: $h" }
      } catch { Log ('Indirme hatasi: ' + $_.Exception.Message) }
    }
    if ($ok) { break }
  }
  if (-not $ok) { Fail "Electron indirilemedi. Internet / proxy / guvenlik duvarini kontrol et (github.com acik olmali). Detay: kurulum-log.txt" }

  $tmp = Join-Path $root 'electron_tmp'
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  New-Item -ItemType Directory -Path $tmp | Out-Null

  Log 'Dosyalar aciliyor...'
  Write-Host 'Dosyalar aciliyor, biraz surebilir...'
  $extracted = $false
  $tar = Join-Path $env:SystemRoot 'System32\tar.exe'
  if (Test-Path $tar) {
    & $tar -xf $zip -C $tmp
    if ($LASTEXITCODE -eq 0) { $extracted = $true } else { Log "tar hata kodu $LASTEXITCODE, Expand-Archive deneniyor" }
  }
  if (-not $extracted) { Expand-Archive -Path $zip -DestinationPath $tmp -Force }

  if (-not (Test-Path (Join-Path $tmp 'electron.exe'))) {
    Fail "electron.exe cikarilamadi. Antivirus engellemis olabilir; bu klasoru antivirus istisnalarina ekleyip tekrar dene."
  }

  $dest = Join-Path $root 'electron'
  if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
  Move-Item -Path $tmp -Destination $dest
  Remove-Item $dl -Recurse -Force -ErrorAction SilentlyContinue

  Start-Sleep -Seconds 3   # antivirusun dosyayi silip silmedigini yakala
  if (-not (Test-Exe)) {
    Fail "electron.exe kurulumdan sonra kayboldu (antivirus silmis olabilir). Klasoru antivirus istisnalarina ekle ve tekrar calistir."
  }
  Log 'Electron kuruldu.'
}

# Gorev yoneticisinde "Electron" yerine "Karel Santral" gorunsun (exe'nin adini/aciklamasini/ikonunu degistirir).
# Basarisiz olursa sessizce eski electron.exe ile devam eder; uygulama bozulmaz.
$appName   = 'Karel Santral'
$brandedExe = Join-Path $root ('electron\' + $appName + '.exe')
$rcedit    = Join-Path $root 'tools\rcedit-x64.exe'
$rceditSha = '3e7801db1a5edbec91b49a24a094aad776cb4515488ea5a4ca2289c400eade2a'

function Test-Branded {
  try { return ((Test-Path $brandedExe) -and ((Get-Item $brandedExe).VersionInfo.FileDescription -eq $appName)) } catch { return $false }
}

function Set-Branding {
  try {
    if (Test-Branded) { return }
    if (-not (Test-Path $rcedit)) { Log 'rcedit bulunamadi, marka adi atlandi.'; return }
    if ((Get-FileHash -Path $rcedit -Algorithm SHA256).Hash.ToLower() -ne $rceditSha) { Log 'rcedit SHA256 uyusmadi, marka adi atlandi.'; return }
    $tmpExe = Join-Path $root ('electron\_brand_tmp.exe')
    Copy-Item -Path $exe -Destination $tmpExe -Force
    $icon = Join-Path $root 'app\icon.ico'
    & $rcedit $tmpExe `
      --set-version-string 'FileDescription' $appName `
      --set-version-string 'ProductName' $appName `
      --set-version-string 'InternalName' $appName `
      --set-version-string 'OriginalFilename' ($appName + '.exe') `
      --set-version-string 'CompanyName' 'Karel Santral' `
      --set-version-string 'LegalCopyright' 'Karel Santral' `
      --set-icon $icon
    if ($LASTEXITCODE -ne 0) { throw "rcedit hata kodu $LASTEXITCODE" }
    if (Test-Path $brandedExe) { Remove-Item $brandedExe -Force -ErrorAction SilentlyContinue }
    Move-Item -Path $tmpExe -Destination $brandedExe -Force
    if (Test-Branded) { Log 'Marka adi uygulandi.' } else { Log 'Marka adi dogrulanamadi.' }
  } catch {
    Log ('Marka adi uygulanamadi (sorun degil): ' + $_.Exception.Message)
    Remove-Item (Join-Path $root 'electron\_brand_tmp.exe') -Force -ErrorAction SilentlyContinue
  }
}

try {
  if (-not (Test-Exe)) { Install-Electron }

  Set-Branding
  $runExe = $exe
  if (Test-Branded) { $runExe = $brandedExe }

  # Masaustu kisayolu (her calistirmada yenilenir, klasor tasinsa da dogru kalir)
  try {
    $desk = [Environment]::GetFolderPath('Desktop')
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desk 'Karel Santral.lnk'))
    $s.TargetPath       = $runExe
    $s.Arguments        = '"' + $root + '"'
    $s.WorkingDirectory = $root
    $ic = Join-Path $root 'app\icon.ico'
    if (Test-Path $ic) { $s.IconLocation = $ic }
    $s.Save()
  } catch { Log ('Kisayol olusturulamadi: ' + $_.Exception.Message) }

  Log 'Uygulama aciliyor.'
  Start-Process -FilePath $runExe -ArgumentList ('"' + $root + '"') -WorkingDirectory $root
  exit 0
} catch {
  Fail ('Beklenmeyen hata: ' + $_.Exception.Message)
}
