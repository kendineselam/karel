@echo off
title Karel Santral - Kurulum
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Karel-Kur.ps1"
if errorlevel 1 pause
