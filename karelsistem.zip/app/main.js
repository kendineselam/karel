const { app, BrowserWindow, Menu, Tray, Notification, nativeImage, ipcMain, screen, session, shell, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const vm = require('vm');
const { execFile } = require('child_process');

// ================= AYARLAR =================
const SITE_URL = 'https://santral.karel.cloud/user/internalstatus';
const SITE_HOST = 'santral.karel.cloud';
const REPO_RAW = 'https://raw.githubusercontent.com/kendineselam/karel/main/';
const UPDATE_FILE = 'guncelleme.txt';  // TEK kontrol dosyasi: program surumu + script surumu + script listesi
const MANIFEST = 'manifest.json';      // (sadece bilgisayardaki kayit dosyasi, GitHub'da gerekmez)
const ZIP_NAME = 'karelsistem.zip';    // programin kendisi (tam guncelleme)
const VER_FILE = 'appversion.txt';     // bilgisayardaki program surumu (app klasorunde)
const NOTES_FILE = 'yenilikler.txt';  // GitHub'da: guncelleme sonrasi gosterilecek "yenilikler" listesi (her satir bir madde)
// ===========================================

app.setAppUserModelId('com.karel.santral');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
// Pencere kucukken / arkadayken / tepsideyken de cagri yakalamaya devam etsin
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
if (!app.requestSingleInstanceLock()) app.quit();

const APP_DIR = __dirname;
const ROOT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const scriptsDir = () => path.join(app.getPath('userData'), 'scripts');

let splash = null;
let win = null;
let tray = null;
let quitting = false;
let current = null; // yuklu script manifesti

function log(m) {
  try {
    const f = path.join(ROOT, 'uygulama-log.txt');
    if (fs.existsSync(f) && fs.statSync(f).size > 100 * 1024) fs.rmSync(f, { force: true });
    fs.appendFileSync(f, new Date().toLocaleString('tr-TR') + ' ' + m + '\n');
  } catch (e) {}
}

// ================== KULLANICI AYARLARI ==================
const DEFAULTS = {
  showNotifications: true,  // bildirimler genel anahtar
  popup: true,              // ekran popup'i (her zaman ustte)
  toast: true,              // Windows bildirimi
  inPage: false,            // sitedeki sari popup
  bringToFront: false,      // cagri gelince pencereyi one getir
  position: 'top-right',
  duration: 20,             // sn, 0 = ben kapatana kadar
  startWithWindows: false,
  startMinimized: false,
  closeToTray: true
};
let settings = { ...DEFAULTS };
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');
function loadSettings() {
  try { settings = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(settingsFile(), 'utf8')) }; } catch (e) {}
}
function saveSettings() {
  try {
    fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
    fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2));
  } catch (e) { log('Ayar kaydedilemedi: ' + e.message); }
}

const POSITIONS = [
  ['top-right', 'Sağ üst'], ['bottom-right', 'Sağ alt'], ['top-left', 'Sol üst'], ['bottom-left', 'Sol alt'],
  ['top-center', 'Üst orta'], ['bottom-center', 'Alt orta'], ['center', 'Ekranın ortası']
];
const DURATIONS = [[5, '5 saniye'], [10, '10 saniye'], [20, '20 saniye'], [30, '30 saniye'], [60, '60 saniye'], [0, 'Ben kapatana kadar']];

function applyLoginItem() {
  try {
    app.setLoginItemSettings({
      openAtLogin: !!settings.startWithWindows,
      path: process.execPath,
      args: [ROOT].concat(settings.startMinimized ? ['--hidden'] : [])
    });
  } catch (e) { log('Windows ile başlatma ayarlanamadı: ' + e.message); }
}

function setSetting(key, value) {
  settings[key] = value;
  saveSettings();
  if (key === 'startWithWindows' || key === 'startMinimized') applyLoginItem();
  if (key === 'inPage') applyInPage();
  buildMenu();
  if (key === 'position' || key === 'duration') previewNotification(); // ayar degisince ornek goster
}

// ================== YARDIMCILAR ==================
function localAppVersion() {
  try { return parseInt(fs.readFileSync(path.join(APP_DIR, VER_FILE), 'utf8').trim(), 10) || 0; } catch (e) { return 0; }
}
async function fetchBuf(url, ms = 15000) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), ms);
  try {
    const r = await fetch(url, { signal: ac.signal, cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return Buffer.from(await r.arrayBuffer());
  } finally { clearTimeout(t); }
}
const fetchText = async (url, ms) => (await fetchBuf(url, ms)).toString('utf8');

function run(file, args) {
  return new Promise((res, rej) => execFile(file, args, { windowsHide: true }, (e) => (e ? rej(e) : res())));
}
async function extractZip(zip, dest) {
  const tar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
  try {
    if (!fs.existsSync(tar)) throw new Error('tar yok');
    await run(tar, ['-xf', zip, '-C', dest]);
  } catch (e) {
    await run('powershell.exe', ['-NoProfile', '-Command',
      `Expand-Archive -LiteralPath '${zip}' -DestinationPath '${dest}' -Force`]);
  }
}

// ================== GUNCELLEME (program + scriptler) ==================
const MIN_CHECK_MS = 1800; // açılışta "güncelleme var mı" ekranı en az bu kadar sürer (eskiden 5000)
const DONE_HOLD_MS = 500;  // son mesaj ekranda bu kadar kalıp kapanır

function readLocalManifest() {
  try {
    const m = JSON.parse(fs.readFileSync(path.join(scriptsDir(), MANIFEST), 'utf8'));
    if (m.scripts.every((f) => fs.existsSync(path.join(scriptsDir(), f)))) return m;
  } catch (e) {}
  return null;
}

// --- tek dosyadan oku: guncelleme.txt ---
//   program=4                      -> programın kendisi (karelsistem.zip)
//   script=1                       -> scriptler
//   karel-call-notifier.user.js    -> indirilecek script dosyaları (her satıra bir tane)
//   # ile başlayan satırlar yorum
function parseUpdateTxt(txt) {
  const out = { program: NaN, script: '', scripts: [] };
  for (let line of txt.replace(/^\uFEFF/, '').split(/\r?\n/)) {
    line = line.trim();
    if (!line || line.startsWith('#')) continue;
    const m = line.match(/^(program|script)\s*=\s*(.+)$/i);
    if (m) {
      if (m[1].toLowerCase() === 'program') out.program = parseInt(m[2], 10);
      else out.script = m[2].trim();
    } else out.scripts.push(line);
  }
  if (!Number.isInteger(out.program) || !out.script) throw new Error('guncelleme.txt bozuk (program= ve script= satırları gerekli)');
  return out;
}
async function queryRemote() {
  try { return parseUpdateTxt(await fetchText(REPO_RAW + UPDATE_FILE + '?t=' + Date.now(), 10000)); }
  catch (e) { log('guncelleme.txt okunamadı: ' + e.message); return null; }
}

// --- programın kendisini güncelle (appversion.txt + karelsistem.zip) ---
async function applyAppUpdate(info, say) {
  const { local, remote } = info;
  const work = path.join(os.tmpdir(), 'karel_update');
  try {
    fs.rmSync(work, { recursive: true, force: true });
    fs.mkdirSync(path.join(work, 'x'), { recursive: true });

    say(`Program güncelleniyor: v${local} → v${remote} — indiriliyor...`, 45);
    const zipPath = path.join(work, 'update.zip');
    fs.writeFileSync(zipPath, await fetchBuf(REPO_RAW + ZIP_NAME + '?t=' + Date.now(), 180000));

    say('Dosyalar açılıyor...', 60);
    const ex = path.join(work, 'x');
    await extractZip(zipPath, ex);

    // kontrol: dosyalar tam mi, surum uyuyor mu, kodda sozdizimi hatasi var mi
    const nApp = path.join(ex, 'app');
    for (const f of ['main.js', 'splash.html', VER_FILE]) {
      if (!fs.existsSync(path.join(nApp, f))) throw new Error('zip eksik: app/' + f);
    }
    const zv = parseInt(fs.readFileSync(path.join(nApp, VER_FILE), 'utf8').trim(), 10);
    if (zv !== remote) log(`Uyarı: zip içindeki sürüm (${zv}) guncelleme.txt'deki program sürümü (${remote}) ile aynı değil; ${remote} olarak işaretlenecek`);
    new vm.Script(fs.readFileSync(path.join(nApp, 'main.js'), 'utf8')); // sozdizimi kontrolu

    say('Kuruluyor...', 80);
    const backup = path.join(ROOT, 'app_yedek');
    fs.rmSync(backup, { recursive: true, force: true });
    fs.cpSync(APP_DIR, backup, { recursive: true });
    fs.cpSync(nApp, APP_DIR, { recursive: true, force: true });
    fs.writeFileSync(path.join(APP_DIR, VER_FILE), String(remote)); // surum her zaman guncelleme.txt ile ayni olsun (sonsuz guncelleme dongusu olmasin)

    log(`Program güncellendi: v${local} -> v${remote}`);
    say('Güncelleme tamam! Program yeniden başlatılıyor...', 100);
    await sleep(700);
    fs.rmSync(work, { recursive: true, force: true });
    quitting = true;
    app.relaunch();
    app.exit(0);
    return true;
  } catch (e) {
    log('Program güncellemesi başarısız: ' + e.message);
    fs.rmSync(work, { recursive: true, force: true });
    say('Program güncellemesi olmadı (' + String(e.message).slice(0, 60) + '), mevcut sürümle devam ediyoruz', 100);
    await sleep(1100);
    return false;
  }
}

// --- scriptleri güncelle (manifest.json + .user.js dosyaları) ---
async function applyScripts(info, say) {
  const { local, remote } = info;
  const tmp = scriptsDir() + '_new';
  try {
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.mkdirSync(tmp, { recursive: true });
    const n = remote.scripts.length;
    for (let i = 0; i < n; i++) {
      const f = remote.scripts[i];
      if (f.includes('..')) throw new Error('geçersiz dosya adı');
      say(`Scriptler indiriliyor (${i + 1}/${n}): ${f}`, 45 + Math.round((50 * i) / n));
      const code = await fetchText(REPO_RAW + encodeURI(f) + '?t=' + Date.now(), 20000);
      if (code.trim().length < 10 || /^\s*<!doctype html/i.test(code)) throw new Error(f + ' geçersiz');
      const dest = path.join(tmp, f);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, code);
    }
    fs.writeFileSync(path.join(tmp, MANIFEST), JSON.stringify(remote, null, 2));
    fs.rmSync(scriptsDir(), { recursive: true, force: true });
    try { fs.renameSync(tmp, scriptsDir()); }
    catch (re) { fs.cpSync(tmp, scriptsDir(), { recursive: true, force: true }); fs.rmSync(tmp, { recursive: true, force: true }); }
    log('Scriptler güncellendi: v' + remote.version);
    say('Scriptler güncellendi!', 100);
    await sleep(500);
    return remote;
  } catch (e) {
    log('Script güncellemesi başarısız: ' + e.message);
    fs.rmSync(tmp, { recursive: true, force: true });
    say('Script güncellemesi olmadı (' + String(e.message).slice(0, 60) + '), ' + (local ? 'kayıtlı sürümle devam ediyoruz' : 'script bulunamadı'), 100);
    await sleep(1100);
    return local;
  }
}

// --- yenilikler penceresi: yenilikler.txt degisince bir kez gosterilir ---
//   (eski surumlerin guncelleme.txt'sine dokunmaz, ayri dosya)
const notesSeenFile = () => path.join(app.getPath('userData'), 'notes-seen.txt');
async function showNotes(force) {
  try {
    const txt = await fetchText(REPO_RAW + NOTES_FILE + '?t=' + Date.now(), 8000);
    const lines = txt.replace(/^\uFEFF/, '').split(/\r?\n/).map((l) => l.trim()).filter((l) => l && !l.startsWith('#'));
    if (!lines.length) { if (force) await dialog.showMessageBox({ type: 'info', title: 'Karel Santral', message: 'Şu an gösterilecek yenilik yok.', buttons: ['Tamam'] }); return; }
    const sig = require('crypto').createHash('sha1').update(lines.join('\n')).digest('hex');
    let seen = '';
    try { seen = fs.readFileSync(notesSeenFile(), 'utf8').trim(); } catch (e) {}
    if (!force && seen === sig) return;
    try { fs.mkdirSync(path.dirname(notesSeenFile()), { recursive: true }); fs.writeFileSync(notesSeenFile(), sig); } catch (e) {}
    const opts = {
      type: 'info', title: 'Karel Santral — Yenilikler', buttons: ['Tamam'],
      message: force ? 'Son güncellemedeki yenilikler' : 'Güncelleme tamamlandı 🎉',
      detail: 'Yenilikler:\n\n' + lines.map((l) => '•  ' + l).join('\n') +
        `\n\nProgram v${localAppVersion()}  •  Script ${current ? 'v' + current.version : '-'}`
    };
    if (win && !win.isDestroyed() && win.isVisible()) await dialog.showMessageBox(win, opts);
    else await dialog.showMessageBox(opts);
  } catch (e) { log('Yenilikler gösterilemedi: ' + e.message); }
}

// --- tüm akış: bak → mesaj göster → gerekirse indir ---
async function runUpdateFlow(say, opts = {}) {
  const minMs = opts.minMs === undefined ? MIN_CHECK_MS : opts.minMs;
  const t0 = Date.now();
  say('Güncelleme var mı yok mu bakıyorum...', 15);
  const remote = await queryRemote();
  const appInfo = remote ? { local: localAppVersion(), remote: remote.program } : null;
  const scrInfo = {
    local: readLocalManifest(),
    remote: remote ? { version: remote.script, scripts: remote.scripts } : null,
    failed: !remote
  };

  const appNew = !!appInfo && appInfo.remote > appInfo.local;
  const scrNew = !!scrInfo.remote && (!scrInfo.local || String(scrInfo.local.version) !== String(scrInfo.remote.version));
  let manifest = scrInfo.local;

  if (!appInfo && scrInfo.failed) {
    say('İnternete ulaşamadım, olduğu gibi devam ediyoruz', 100);
  } else if (!appNew && !scrNew) {
    say('Her şey güncel, devam edelim! ✔', 100);
  } else {
    say('Aaa, güncelleme var! 🎉', 35);
    await sleep(1000);
    // scriptler programdan bağımsız güncellenir: program güncellemesi olmasa/başarısız olsa da script gelir
    if (scrNew) manifest = await applyScripts(scrInfo, say);
    if (appNew && (await applyAppUpdate(appInfo, say))) return { relaunching: true, manifest };
  }

  const left = minMs - (Date.now() - t0);
  if (left > 0) await sleep(left);
  return { relaunching: false, manifest };
}

// ---------- @match isleme ----------
function globToRegex(g) {
  if (g === '*' || g === '<all_urls>') return /^https?:\/\/.*/;
  const esc = g.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
  return new RegExp('^' + esc + '$');
}
function parseHeader(code) {
  const h = (code.match(/==UserScript==([\s\S]*?)==\/UserScript==/) || [])[1] || '';
  const grab = (tag) => [...h.matchAll(new RegExp('@' + tag + '\\s+(\\S+)', 'g'))].map((m) => m[1]);
  return { match: [...grab('match'), ...grab('include')], exclude: grab('exclude') };
}
function shouldRun(meta, url) {
  if (meta.exclude.some((g) => globToRegex(g).test(url))) return false;
  if (meta.match.length === 0) return true;
  return meta.match.some((g) => globToRegex(g).test(url));
}
async function injectScripts(wc) {
  if (!current) return;
  const url = wc.getURL();
  for (const f of current.scripts) {
    try {
      const code = fs.readFileSync(path.join(scriptsDir(), f), 'utf8');
      if (!shouldRun(parseHeader(code), url)) continue;
      const key = JSON.stringify(f);
      await wc.executeJavaScript(
        `(function(){window.__ks=window.__ks||{};if(window.__ks[${key}])return;window.__ks[${key}]=1;\n${code}\n})();`
      );
      log('Script çalıştı: ' + f);
    } catch (e) { log('Script hatası (' + f + '): ' + e.message); }
  }
}

// ================== SAYFAYA KOPRU ==================
// Bu fonksiyon sayfanin icinde calisir (toString ile enjekte edilir).
// - Sayfanin kendi Notification'ini susturur (Windows bildirimini artik uygulama yonetir)
// - Scriptin actigi sari popup'lari (data-call-id) izler ve uygulamaya haber verir
function bridgeMain() {
  if (window.__karelBridgeOn) return;
  window.__karelBridgeOn = true;

  try {
    var Fake = function () {};
    Fake.permission = 'granted';
    Fake.requestPermission = function (cb) { if (cb) cb('granted'); return Promise.resolve('granted'); };
    Fake.prototype.close = function () {};
    window.Notification = Fake;
  } catch (e) {}

  var st = document.createElement('style');
  st.id = 'karel-hide-inpage';
  (document.head || document.documentElement).appendChild(st);
  window.__karelHideInPage = function (hide) {
    st.textContent = hide ? '[data-call-id]{display:none!important}' : '';
  };

  function numberOf(n) {
    var s = n.querySelector('span');
    var t = ((s ? s.textContent : n.textContent) || '').trim();
    var m = t.match(/Arayan Numara:\s*(.+)$/);
    return (m ? m[1] : t).trim();
  }
  function each(list, fn) {
    list.forEach(function (n) {
      if (n.nodeType !== 1) return;
      if (n.hasAttribute('data-call-id')) fn(n);
      n.querySelectorAll('[data-call-id]').forEach(fn);
    });
  }
  new MutationObserver(function (muts) {
    muts.forEach(function (m) {
      each(m.addedNodes, function (n) {
        try { window.__karel.callAdded(n.getAttribute('data-call-id'), numberOf(n)); } catch (e) {}
      });
      each(m.removedNodes, function (n) {
        try { window.__karel.callRemoved(n.getAttribute('data-call-id')); } catch (e) {}
      });
    });
  }).observe(document.body, { childList: true, subtree: true });
}

function injectBridge(wc) {
  return wc.executeJavaScript(
    '(' + bridgeMain.toString() + ')();window.__karelHideInPage(' + (!settings.inPage) + ');'
  ).catch((e) => log('Köprü hatası: ' + e.message));
}
function applyInPage() {
  if (!win || win.isDestroyed()) return;
  win.webContents.executeJavaScript(
    'window.__karelHideInPage&&window.__karelHideInPage(' + (!settings.inPage) + ')'
  ).catch(() => {});
}
function closeInPage(id) {
  if (!win || win.isDestroyed()) return;
  win.webContents.executeJavaScript(
    '(function(){var n=document.querySelector("[data-call-id=" + JSON.stringify(' + JSON.stringify(id) + ') + "]");' +
    'var b=n&&n.querySelector("button");if(b)b.click();})()'
  ).catch(() => {});
}

// ================== EKRAN POPUP'LARI ==================
const POP_W = 380, POP_H = 96, POP_GAP = 10, POP_MARGIN = 16, MAX_POPUPS = 4;
const popups = new Map(); // id -> { win, timer }

function popupBounds(index, count, wa) {
  const pos = settings.position;
  let x;
  if (pos.endsWith('right')) x = wa.x + wa.width - POP_W - POP_MARGIN;
  else if (pos.endsWith('left')) x = wa.x + POP_MARGIN;
  else x = Math.round(wa.x + (wa.width - POP_W) / 2);
  let y;
  if (pos.startsWith('top')) y = wa.y + POP_MARGIN + index * (POP_H + POP_GAP);
  else if (pos.startsWith('bottom')) y = wa.y + wa.height - POP_H - POP_MARGIN - index * (POP_H + POP_GAP);
  else y = Math.round(wa.y + (wa.height - POP_H) / 2 + (index - (count - 1) / 2) * (POP_H + POP_GAP));
  return { x, y, width: POP_W, height: POP_H };
}

function layoutPopups() {
  const ref = win && !win.isDestroyed() ? win.getBounds() : null;
  const display = ref ? screen.getDisplayMatching(ref) : screen.getPrimaryDisplay();
  const list = [...popups.values()].filter((p) => !p.win.isDestroyed());
  list.forEach((p, i) => p.win.setBounds(popupBounds(i, list.length, display.workArea)));
}

function dismiss(id, fromUser) {
  const p = popups.get(id);
  if (!p) return;
  clearTimeout(p.timer);
  popups.delete(id);
  if (!p.win.isDestroyed()) p.win.destroy();
  layoutPopups();
  if (fromUser) closeInPage(id); // kullanici kapattiysa sitedeki popup da kapansin (cagri sesi de durur)
}

function createPopup(id, number) {
  while (popups.size >= MAX_POPUPS) dismiss(popups.keys().next().value, false);
  const w = new BrowserWindow({
    width: POP_W, height: POP_H, frame: false, transparent: true, resizable: false, movable: false,
    minimizable: false, maximizable: false, skipTaskbar: true, alwaysOnTop: true, focusable: false,
    show: false, hasShadow: false,
    webPreferences: { preload: path.join(APP_DIR, 'popup-preload.js'), contextIsolation: true, backgroundThrottling: false }
  });
  w.setAlwaysOnTop(true, 'screen-saver');
  const entry = { win: w, timer: null };
  popups.set(id, entry);
  if (settings.duration > 0) entry.timer = setTimeout(() => dismiss(id, false), settings.duration * 1000);
  w.on('closed', () => { clearTimeout(entry.timer); if (popups.get(id) === entry) popups.delete(id); });
  w.loadFile(path.join(APP_DIR, 'popup.html'));
  w.webContents.once('did-finish-load', () => {
    if (w.isDestroyed()) return;
    w.webContents.send('popup-data', {
      number,
      time: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      duration: settings.duration
    });
    layoutPopups();
    w.showInactive();
  });
}

function showToast(number) {
  try {
    if (!Notification.isSupported()) return;
    const n = new Notification({ title: 'Gelen çağrı', body: number, icon: iconPath(), silent: true });
    n.on('click', showMain);
    n.show();
  } catch (e) { log('Windows bildirimi gösterilemedi: ' + e.message); }
}

function showCall(id, number, opts = {}) {
  if (!opts.force && !settings.showNotifications) return;
  if (popups.has(id)) return;
  if (settings.popup) createPopup(id, number);
  if (settings.toast && !opts.noToast) showToast(number);
  if (settings.bringToFront && !opts.test) showMain();
}

function previewNotification() { // ayar degisince: sadece ekran popup'i, ornek
  if (!settings.popup) return;
  showCall('test-' + Date.now(), '0 (5xx) 000 00 00  — deneme', { force: true, test: true, noToast: true });
}
function sendTest() {
  showCall('test-' + Date.now(), '0 (5xx) 000 00 00  — deneme', { force: true, test: true });
}

// ----- sayfadan gelen olaylar -----
function fromSite(e) {
  try { return new URL(e.senderFrame.url).hostname === SITE_HOST; } catch (err) { return false; }
}
ipcMain.on('call-added', (e, id, number) => { if (fromSite(e) && id) showCall(id, number || '?'); });
ipcMain.on('call-removed', (e, id) => {
  if (!fromSite(e)) return;
  const p = popups.get(id);
  if (p && !p.win.isDestroyed()) p.win.webContents.send('popup-ended'); // cagri bitti, popup suresi dolana kadar kalir
});
// ----- popup'tan gelen olaylar -----
function idOfSender(wc) {
  for (const [id, p] of popups) if (!p.win.isDestroyed() && p.win.webContents.id === wc.id) return id;
  return null;
}
ipcMain.on('popup-close', (e) => { const id = idOfSender(e.sender); if (id) dismiss(id, true); });
ipcMain.on('popup-open', (e) => { const id = idOfSender(e.sender); showMain(); if (id) dismiss(id, false); });

// ================== PENCERELER ==================
const iconPath = () => { const p = path.join(APP_DIR, 'icon.ico'); return fs.existsSync(p) ? p : undefined; };
function brandTaskbar(w) { // Windows gorev cubugu ikonu: exe'nin Electron ikonu yerine icon.ico kullan
  try {
    const p = iconPath();
    if (p && w && !w.isDestroyed() && typeof w.setAppDetails === 'function') {
      w.setAppDetails({ appId: 'com.karel.santral', appIconPath: p, appIconIndex: 0 });
    }
  } catch (e) { log('Görev çubuğu ikonu ayarlanamadı: ' + e.message); }
}
let _iconImg = null;
function iconImage() { // gorev cubugunda Electron logosu yerine Karel ikonu
  try {
    if (_iconImg) return _iconImg;
    for (const f of ['icon.png', 'icon.ico']) {
      const fp = path.join(APP_DIR, f);
      if (!fs.existsSync(fp)) continue;
      const img = nativeImage.createFromPath(fp);
      if (!img.isEmpty()) { _iconImg = img; log('Pencere ikonu yüklendi: ' + f + ' ' + JSON.stringify(img.getSize())); break; }
      log('Pencere ikonu BOŞ geldi: ' + f);
    }
    return _iconImg || iconPath();
  } catch (e) { return iconPath(); }
}

function showMain() {
  if (!win || win.isDestroyed()) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

function createSplash() {
  splash = new BrowserWindow({
    width: 440, height: 230, frame: false, resizable: false, center: true, alwaysOnTop: true,
    show: false, backgroundColor: '#14171c', icon: iconImage(), skipTaskbar: true,
    webPreferences: { contextIsolation: true }
  });
  brandTaskbar(splash);
  splash.loadFile(path.join(APP_DIR, 'splash.html'));
  return new Promise((res) => splash.webContents.once('did-finish-load', () => { splash.show(); res(); }));
}
function say(text, pct) {
  if (splash && !splash.isDestroyed()) {
    splash.webContents.executeJavaScript(`setStatus(${JSON.stringify(text)},${pct})`).catch(() => {});
  }
}
const titleOf = () => 'Karel Santral';

function createMain(hidden) {
  win = new BrowserWindow({
    width: 1280, height: 800, show: !hidden, title: titleOf(), icon: iconImage(),
    webPreferences: {
      preload: path.join(APP_DIR, 'preload.js'),
      contextIsolation: true,
      backgroundThrottling: false // arka planda da çağrı yakalasın
    }
  });
  try { const im = iconImage(); if (im) win.setIcon(im); } catch (e) {}
  brandTaskbar(win);
  win.on('page-title-updated', (e) => e.preventDefault());
  win.webContents.on('did-finish-load', async () => {
    await injectBridge(win.webContents);
    await injectScripts(win.webContents);
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith('https://' + SITE_HOST)) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow' };
  });
  win.on('close', (e) => {
    if (!quitting && settings.closeToTray) { e.preventDefault(); win.hide(); }
  });
  win.on('closed', () => { [...popups.keys()].forEach((id) => dismiss(id, false)); app.quit(); });
  win.loadURL(SITE_URL);
}

function createTray() {
  const ic = iconPath();
  if (!ic) return;
  tray = new Tray(iconImage() || nativeImage.createFromPath(ic));
  tray.setToolTip('Karel Santral');
  tray.on('click', showMain);
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Göster', click: showMain },
    { label: 'Deneme bildirimi gönder', click: sendTest },
    { type: 'separator' },
    { label: 'Çıkış', click: () => { quitting = true; app.quit(); } }
  ]));
}

function buildMenu() {
  const chk = (label, key) => ({
    label, type: 'checkbox', checked: !!settings[key], click: (mi) => setSetting(key, mi.checked)
  });
  const radios = (items, key) => items.map(([v, l]) => ({
    label: l, type: 'radio', checked: settings[key] === v, click: () => setSetting(key, v)
  }));
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {
      label: 'Karel',
      submenu: [
        { label: 'Yenile', accelerator: 'F5', click: () => win && win.reload() },
        { label: 'Geliştirici araçları', accelerator: 'F12', click: () => win && win.webContents.openDevTools({ mode: 'detach' }) },
        { type: 'separator' },
        { label: 'Çıkış', click: () => { quitting = true; app.quit(); } }
      ]
    },
    {
      label: 'Güncelleme',
      submenu: [
        { label: `Program v${localAppVersion()}  •  Script ${current ? 'v' + current.version : '-'}`, enabled: false },
        { type: 'separator' },
        { label: 'Güncellemeleri denetle', accelerator: 'Ctrl+U', click: manualUpdate },
        { label: 'Yenilikleri göster', click: () => showNotes(true) }
      ]
    },
    {
      label: 'Bildirimler',
      submenu: [
        chk('Bildirimleri göster', 'showNotifications'),
        { type: 'separator' },
        chk('Ekran popup\'ı (her zaman üstte)', 'popup'),
        chk('Windows bildirimi', 'toast'),
        chk('Sitedeki sarı popup\'ı da göster', 'inPage'),
        chk('Çağrı gelince pencereyi öne getir', 'bringToFront'),
        { type: 'separator' },
        { label: 'Konum', submenu: radios(POSITIONS, 'position') },
        { label: 'Ekranda kalma süresi', submenu: radios(DURATIONS, 'duration') },
        { type: 'separator' },
        { label: 'Deneme bildirimi gönder', click: sendTest }
      ]
    },
    {
      label: 'Ayarlar',
      submenu: [
        chk('Windows ile başlat', 'startWithWindows'),
        chk('Başlangıçta küçültülmüş (arka planda) aç', 'startMinimized'),
        chk('Pencereyi kapatınca arka planda çalışmaya devam et', 'closeToTray')
      ]
    }
  ]));
}

let updating = false;
async function manualUpdate() {
  if (updating) return;
  updating = true;
  try {
    await createSplash();
    const r = await runUpdateFlow(say);
    if (r.relaunching) return;
    const before = current ? String(current.version) : '';
    if (r.manifest) current = r.manifest;
    buildMenu();
    if (splash && !splash.isDestroyed()) splash.close();
    if (win && !win.isDestroyed() && (current ? String(current.version) : '') !== before) win.reload(); // yeni script geldiyse
    showNotes(false); // yenilikler.txt degistiyse goster
  } finally { updating = false; }
}

// ================== GIRIS BILGILERI KALICI OLSUN ==================
// Site "oturum çerezi" (süresiz) verirse program kapanınca giriş silinir.
// Burada bu çerezlere 30 günlük süre vererek giriş bilgisinin kalıcı olmasını sağlıyoruz.
function persistSessionCookies() {
  const ses = session.defaultSession;
  ses.cookies.on('changed', (e, cookie, cause, removed) => {
    if (removed || !cookie.session) return;
    try {
      const host = cookie.domain.replace(/^\./, '');
      const details = {
        url: (cookie.secure ? 'https://' : 'http://') + host + (cookie.path || '/'),
        name: cookie.name, value: cookie.value, path: cookie.path || '/',
        secure: cookie.secure, httpOnly: cookie.httpOnly, sameSite: cookie.sameSite,
        expirationDate: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 30
      };
      if (!cookie.hostOnly) details.domain = cookie.domain;
      ses.cookies.set(details).catch(() => {});
    } catch (err) {}
  });
}

// ================== BASLANGIC ==================
app.on('before-quit', () => {
  quitting = true;
  try { session.defaultSession.cookies.flushStore(); } catch (e) {}
});
app.on('second-instance', () => showMain());

app.whenReady().then(async () => {
  loadSettings();
  log('Açılış: program v' + localAppVersion() + ' | exe: ' + process.execPath + ' | electron ' + process.versions.electron);
  applyLoginItem(); // klasor tasinsa da Windows ile baslatma yolu guncel kalsin
  persistSessionCookies();
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(true));
  session.defaultSession.setPermissionCheckHandler(() => true);

  const hidden = process.argv.includes('--hidden'); // Windows ile başlayınca sessiz aç
  if (!hidden) await createSplash();

  const r = await runUpdateFlow(say, { minMs: hidden ? 0 : MIN_CHECK_MS });
  if (r.relaunching) return; // program yeniden baslatiliyor
  current = r.manifest;

  buildMenu();
  createMain(hidden);
  createTray();
  setTimeout(() => { if (splash && !splash.isDestroyed()) splash.close(); }, DONE_HOLD_MS);
  if (!hidden) setTimeout(() => showNotes(false), DONE_HOLD_MS + 1200); // güncelleme sonrası yenilikler (bir kez)
});
