const { app, BrowserWindow, Menu, session, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const vm = require('vm');
const { execFile } = require('child_process');

// ================= AYARLAR =================
const SITE_URL = 'https://santral.karel.cloud/user/internalstatus';
const REPO_RAW = 'https://raw.githubusercontent.com/kendineselam/karel/main/';
const MANIFEST = 'manifest.json';      // script listesi + script surumu
const ZIP_NAME = 'karelsistem.zip';    // programin kendisi (tam guncelleme)
const VER_FILE = 'appversion.txt';     // program surumu
// ===========================================

app.setAppUserModelId('com.karel.santral');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
if (!app.requestSingleInstanceLock()) app.quit();

const APP_DIR = __dirname;
const ROOT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const scriptsDir = () => path.join(app.getPath('userData'), 'scripts');

let splash = null;
let win = null;
let current = null; // yuklu script manifesti

function log(m) {
  try {
    const f = path.join(ROOT, 'uygulama-log.txt');
    if (fs.existsSync(f) && fs.statSync(f).size > 100 * 1024) fs.rmSync(f, { force: true });
    fs.appendFileSync(f, new Date().toLocaleString('tr-TR') + ' ' + m + '\n');
  } catch (e) {}
}

function localAppVersion() {
  try { return parseInt(fs.readFileSync(path.join(APP_DIR, VER_FILE), 'utf8').trim(), 10) || 0; } catch (e) { return 0; }
}

async function fetchBuf(url, ms = 15000) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), ms);
  try {
    const r = await fetch(url, { signal: ac.signal, cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return Buffer.from(await r.arrayBuffer());
  } finally { clearTimeout(t); }
}
const fetchText = async (url, ms) => (await fetchBuf(url, ms)).toString('utf8');

// ---------- Zip acma (Windows tar.exe, olmazsa PowerShell) ----------
function run(file, args) {
  return new Promise((res, rej) => execFile(file, args, { windowsHide: true }, (e) => (e ? rej(e) : res())));
}
async function extractZip(zip, dest) {
  const tar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
  try {
    if (!fs.existsSync(tar)) throw new Error('tar yok');
    await run(tar, ['-xf', zip, '-C', dest]);
  } catch (e) {
    await run('powershell.exe', ['-NoProfile', '-Command',
      `Expand-Archive -LiteralPath '${zip}' -DestinationPath '${dest}' -Force`]);
  }
}

// ================== 1) PROGRAMIN KENDISI (appversion.txt + karelsistem.zip) ==================
async function checkAppUpdate(say) {
  const local = localAppVersion();
  say('Program surumu kontrol ediliyor...', 15);
  let remote;
  try {
    remote = parseInt((await fetchText(REPO_RAW + VER_FILE + '?t=' + Date.now(), 10000)).trim(), 10);
  } catch (e) { log('Program surumu okunamadi: ' + e.message); return false; }
  if (!Number.isInteger(remote) || remote <= local) return false;

  say(`Yeni program surumu bulundu: v${local} -> v${remote}`, 25);
  await sleep(900);
  const work = path.join(os.tmpdir(), 'karel_update');
  try {
    fs.rmSync(work, { recursive: true, force: true });
    fs.mkdirSync(path.join(work, 'x'), { recursive: true });

    say('Program guncellemesi indiriliyor...', 35);
    const zipPath = path.join(work, 'update.zip');
    fs.writeFileSync(zipPath, await fetchBuf(REPO_RAW + ZIP_NAME + '?t=' + Date.now(), 180000));

    say('Dosyalar aciliyor...', 55);
    const ex = path.join(work, 'x');
    await extractZip(zipPath, ex);

    // kontrol: dosyalar tam mi, surum uyuyor mu, kodda sozdizimi hatasi var mi
    const nApp = path.join(ex, 'app');
    for (const f of ['main.js', 'splash.html', VER_FILE]) {
      if (!fs.existsSync(path.join(nApp, f))) throw new Error('zip eksik: app/' + f);
    }
    const zv = parseInt(fs.readFileSync(path.join(nApp, VER_FILE), 'utf8').trim(), 10);
    if (zv !== remote) throw new Error(`zip surumu (${zv}) appversion.txt (${remote}) ile uyusmuyor`);
    new vm.Script(fs.readFileSync(path.join(nApp, 'main.js'), 'utf8')); // sozdizimi kontrolu

    say('Kuruluyor...', 75);
    const backup = path.join(ROOT, 'app_yedek');
    fs.rmSync(backup, { recursive: true, force: true });
    fs.cpSync(APP_DIR, backup, { recursive: true });
    fs.cpSync(nApp, APP_DIR, { recursive: true, force: true });

    log(`Program guncellendi: v${local} -> v${remote}`);
    say('Program yeniden baslatiliyor...', 100);
    await sleep(900);
    fs.rmSync(work, { recursive: true, force: true });
    app.relaunch();
    app.exit(0);
    return true;
  } catch (e) {
    log('Program guncellemesi basarisiz: ' + e.message);
    fs.rmSync(work, { recursive: true, force: true });
    say('Program guncellemesi basarisiz, mevcut surumle devam ediliyor', 100);
    await sleep(1600);
    return false;
  }
}

// ================== 2) SCRIPTLER (manifest.json + .user.js dosyalari) ==================
function readLocalManifest() {
  try {
    const m = JSON.parse(fs.readFileSync(path.join(scriptsDir(), MANIFEST), 'utf8'));
    if (m.scripts.every((f) => fs.existsSync(path.join(scriptsDir(), f)))) return m;
  } catch (e) {}
  return null;
}

async function checkScripts(say) {
  const local = readLocalManifest();
  say('Scriptler kontrol ediliyor...', 20);
  await sleep(400);

  let remote;
  try {
    remote = JSON.parse(await fetchText(REPO_RAW + MANIFEST + '?t=' + Date.now(), 10000));
    if (!remote.version || !Array.isArray(remote.scripts)) throw new Error('manifest bozuk');
  } catch (e) {
    log('Manifest okunamadi: ' + e.message);
    say(local ? 'Sunucuya ulasilamadi, kayitli scriptler kullaniliyor' : 'Sunucuya ulasilamadi', 100);
    await sleep(1400);
    return local;
  }

  if (local && String(local.version) === String(remote.version)) {
    say('Scriptler guncel - v' + local.version, 100);
    await sleep(700);
    return local;
  }

  say(`Yeni script surumu: ${local ? 'v' + local.version + ' -> ' : ''}v${remote.version}`, 30);
  await sleep(900);

  const tmp = scriptsDir() + '_new';
  try {
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.mkdirSync(tmp, { recursive: true });
    const n = remote.scripts.length;
    for (let i = 0; i < n; i++) {
      const f = remote.scripts[i];
      if (f.includes('..')) throw new Error('gecersiz dosya adi');
      say(`Indiriliyor (${i + 1}/${n}): ${f}`, 30 + Math.round((60 * i) / n));
      const code = await fetchText(REPO_RAW + encodeURI(f) + '?t=' + Date.now(), 20000);
      if (code.trim().length < 10 || /^\s*<!doctype html/i.test(code)) throw new Error(f + ' gecersiz');
      const dest = path.join(tmp, f);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, code);
    }
    fs.writeFileSync(path.join(tmp, MANIFEST), JSON.stringify(remote, null, 2));
    fs.rmSync(scriptsDir(), { recursive: true, force: true });
    fs.renameSync(tmp, scriptsDir());
    log('Scriptler guncellendi: v' + remote.version);
    say('Scriptler guncellendi - v' + remote.version, 100);
    await sleep(1000);
    return remote;
  } catch (e) {
    log('Script guncellemesi basarisiz: ' + e.message);
    fs.rmSync(tmp, { recursive: true, force: true });
    say('Script guncellemesi basarisiz, ' + (local ? 'kayitli surum kullaniliyor' : 'script bulunamadi'), 100);
    await sleep(1600);
    return local;
  }
}

// ---------- @match isleme ----------
function globToRegex(g) {
  if (g === '*' || g === '<all_urls>') return /^https?:\/\/.*/;
  const esc = g.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
  return new RegExp('^' + esc + '$');
}
function parseHeader(code) {
  const h = (code.match(/==UserScript==([\s\S]*?)==\/UserScript==/) || [])[1] || '';
  const grab = (tag) => [...h.matchAll(new RegExp('@' + tag + '\\s+(\\S+)', 'g'))].map((m) => m[1]);
  return { match: [...grab('match'), ...grab('include')], exclude: grab('exclude') };
}
function shouldRun(meta, url) {
  if (meta.exclude.some((g) => globToRegex(g).test(url))) return false;
  if (meta.match.length === 0) return true;
  return meta.match.some((g) => globToRegex(g).test(url));
}
async function injectScripts(wc) {
  if (!current) return;
  const url = wc.getURL();
  for (const f of current.scripts) {
    try {
      const code = fs.readFileSync(path.join(scriptsDir(), f), 'utf8');
      if (!shouldRun(parseHeader(code), url)) continue;
      const key = JSON.stringify(f);
      await wc.executeJavaScript(
        `(function(){window.__ks=window.__ks||{};if(window.__ks[${key}])return;window.__ks[${key}]=1;\n${code}\n})();`
      );
      log('Script calisti: ' + f);
    } catch (e) { log('Script hatasi (' + f + '): ' + e.message); }
  }
}

// ================== PENCERELER ==================
const iconPath = () => { const p = path.join(APP_DIR, 'icon.ico'); return fs.existsSync(p) ? p : undefined; };

function createSplash() {
  splash = new BrowserWindow({
    width: 440, height: 230, frame: false, resizable: false, center: true, alwaysOnTop: true,
    show: false, backgroundColor: '#14171c', icon: iconPath(),
    webPreferences: { contextIsolation: true }
  });
  splash.loadFile(path.join(APP_DIR, 'splash.html'));
  return new Promise((res) => splash.webContents.once('did-finish-load', () => { splash.show(); res(); }));
}
function say(text, pct) {
  if (splash && !splash.isDestroyed()) {
    splash.webContents.executeJavaScript(`setStatus(${JSON.stringify(text)},${pct})`).catch(() => {});
  }
}
const titleOf = () => `Karel Santral - v${localAppVersion()}` + (current ? ` (script v${current.version})` : '');

function createMain() {
  win = new BrowserWindow({
    width: 1280, height: 800, autoHideMenuBar: true, title: titleOf(), icon: iconPath(),
    webPreferences: { contextIsolation: true, backgroundThrottling: false } // arka planda da cagri yakalasin
  });
  win.on('page-title-updated', (e) => e.preventDefault());
  win.webContents.on('did-finish-load', () => injectScripts(win.webContents));
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith('https://santral.karel.cloud')) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow' };
  });

  Menu.setApplicationMenu(Menu.buildFromTemplate([{
    label: 'Karel',
    submenu: [
      { label: 'Guncellemeleri denetle', accelerator: 'Ctrl+U', click: manualUpdate },
      { label: 'Yenile', accelerator: 'F5', click: () => win.reload() },
      { label: 'Gelistirici araclari', accelerator: 'F12', click: () => win.webContents.openDevTools({ mode: 'detach' }) },
      { type: 'separator' },
      { label: 'Cikis', role: 'quit' }
    ]
  }]));

  win.loadURL(SITE_URL);
}

async function manualUpdate() {
  win.setTitle('Guncellemeler kontrol ediliyor...');
  const noop = () => {};
  if (await checkAppUpdate(noop)) return;
  const m = await checkScripts(noop);
  if (m) current = m;
  win.setTitle(titleOf());
  win.reload();
}

// ================== BASLANGIC ==================
app.whenReady().then(async () => {
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(true));
  session.defaultSession.setPermissionCheckHandler(() => true);

  await createSplash();
  say('Guncellemeler kontrol ediliyor...', 5);
  await sleep(500);

  if (await checkAppUpdate(say)) return; // program yeniden baslatiliyor

  current = await checkScripts(say);
  say('Baslatiliyor...', 100);
  createMain();
  setTimeout(() => { if (splash && !splash.isDestroyed()) splash.close(); }, 600);
});

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => app.quit());
