const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('popupApi', {
  onShow: (cb) => ipcRenderer.on('popup-data', (e, d) => cb(d)),
  onEnded: (cb) => ipcRenderer.on('popup-ended', () => cb()),
  close: () => ipcRenderer.send('popup-close'),
  open: () => ipcRenderer.send('popup-open')
});
