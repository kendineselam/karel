const { app, BrowserWindow, session, shell } = require('electron');
const path = require('path');
const fs = require('fs');

// ================= AYARLAR =================
const SITE_URL = 'https://santral.karel.cloud/user/internalstatus';
const REPO_RAW = 'https://raw.githubusercontent.com/kendineselam/karel/main/';
const MANIFEST = 'manifest.json';
// ===========================================

app.setAppUserModelId('com.karel.santral');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

if (!app.requestSingleInstanceLock()) app.quit();

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const scriptsDir = () => path.join(app.getPath('userData'), 'scripts');

let splash = null;
let win = null;
let current = null; // yüklü manifest

// ---------- Yerel manifest ----------
function readLocal() {
  try {
    const m = JSON.parse(fs.readFileSync(path.join(scriptsDir(), MANIFEST), 'utf8'));
    if (m.scripts.every((f) => fs.existsSync(path.join(scriptsDir(), f)))) return m;
  } catch (e) {}
  return null;
}

async function fetchText(url, ms = 10000) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), ms);
  try {
    const r = await fetch(url, { signal: ac.signal, cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.text();
  } finally {
    clearTimeout(t);
  }
}

// ---------- Güncelleme kontrolü ----------
async function checkUpdates(say) {
  const local = readLocal();
  say('Güncellemeler kontrol ediliyor...', 10);
  await sleep(500);

  let remote;
  try {
    remote = JSON.parse(await fetchText(REPO_RAW + MANIFEST + '?t=' + Date.now()));
    if (!remote.version || !Array.isArray(remote.scripts)) throw new Error('manifest bozuk');
  } catch (e) {
    say(local ? 'Sunucuya ulaşılamadı, kayıtlı sürüm kullanılıyor' : 'Sunucuya ulaşılamadı', 100);
    await sleep(1400);
    return local;
  }

  if (local && String(local.version) === String(remote.version)) {
    say('Güncel — v' + local.version, 100);
    await sleep(700);
    return local;
  }

  say(`Yeni sürüm bulundu: ${local ? 'v' + local.version + ' → ' : ''}v${remote.version}`, 25);
  await sleep(900);

  const tmp = scriptsDir() + '_new';
  try {
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.mkdirSync(tmp, { recursive: true });
    const n = remote.scripts.length;
    for (let i = 0; i < n; i++) {
      const f = remote.scripts[i];
      if (f.includes('..')) throw new Error('geçersiz dosya adı');
      say(`İndiriliyor (${i + 1}/${n}): ${f}`, 25 + Math.round((65 * i) / n));
      const code = await fetchText(REPO_RAW + encodeURI(f) + '?t=' + Date.now(), 20000);
      if (code.trim().length < 10 || /^\s*<!doctype html/i.test(code)) throw new Error(f + ' geçersiz');
      const dest = path.join(tmp, f);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, code);
    }
    fs.writeFileSync(path.join(tmp, MANIFEST), JSON.stringify(remote, null, 2));
    fs.rmSync(scriptsDir(), { recursive: true, force: true });
    fs.renameSync(tmp, scriptsDir());
    say('Güncelleme tamamlandı — v' + remote.version, 100);
    await sleep(1000);
    return remote;
  } catch (e) {
    fs.rmSync(tmp, { recursive: true, force: true });
    say('Güncelleme başarısız, ' + (local ? 'kayıtlı sürüm kullanılıyor' : 'script bulunamadı'), 100);
    await sleep(1600);
    return local;
  }
}

// ---------- @match işleme ----------
function globToRegex(g) {
  if (g === '*' || g === '<all_urls>') return /^https?:\/\/.*/;
  const esc = g.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
  return new RegExp('^' + esc + '$');
}

function parseHeader(code) {
  const h = (code.match(/==UserScript==([\s\S]*?)==\/UserScript==/) || [])[1] || '';
  const grab = (tag) => [...h.matchAll(new RegExp('@' + tag + '\\s+(\\S+)', 'g'))].map((m) => m[1]);
  return { match: [...grab('match'), ...grab('include')], exclude: grab('exclude') };
}

function shouldRun(meta, url) {
  if (meta.exclude.some((g) => globToRegex(g).test(url))) return false;
  if (meta.match.length === 0) return true;
  return meta.match.some((g) => globToRegex(g).test(url));
}

async function injectScripts(wc) {
  if (!current) return;
  const url = wc.getURL();
  for (const f of current.scripts) {
    try {
      const code = fs.readFileSync(path.join(scriptsDir(), f), 'utf8');
      if (!shouldRun(parseHeader(code), url)) continue;
      const key = JSON.stringify(f);
      await wc.executeJavaScript(
        `(function(){window.__ks=window.__ks||{};if(window.__ks[${key}])return;window.__ks[${key}]=1;\n${code}\n})();`
      );
      console.log('[inject]', f);
    } catch (e) {
      console.error('[inject hata]', f, e.message);
    }
  }
}

// ---------- Pencereler ----------
function createSplash() {
  splash = new BrowserWindow({
    width: 440, height: 230, frame: false, resizable: false, center: true,
    alwaysOnTop: true, show: false, backgroundColor: '#14171c',
    webPreferences: { contextIsolation: true }
  });
  splash.loadFile(path.join(__dirname, 'splash.html'));
  return new Promise((res) => splash.webContents.once('did-finish-load', () => { splash.show(); res(); }));
}

function say(text, pct) {
  if (splash && !splash.isDestroyed()) {
    splash.webContents.executeJavaScript(`setStatus(${JSON.stringify(text)},${pct})`).catch(() => {});
  }
}

const titleOf = () => 'Karel Santral' + (current ? ' — v' + current.version : '');

function createMain() {
  win = new BrowserWindow({
    width: 1280, height: 800, autoHideMenuBar: true, title: titleOf(),
    webPreferences: { contextIsolation: true, backgroundThrottling: false } // arka planda da çağrı yakalasın
  });
  win.on('page-title-updated', (e) => e.preventDefault());
  win.webContents.on('did-finish-load', () => injectScripts(win.webContents));

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith('https://santral.karel.cloud')) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow' };
  });

  win.webContents.on('before-input-event', (e, input) => {
    if (input.type !== 'keyDown') return;
    if (input.key === 'F5' || (input.control && input.key.toLowerCase() === 'r')) { win.reload(); e.preventDefault(); }
    if (input.control && input.key.toLowerCase() === 'u') { manualUpdate(); e.preventDefault(); }
  });

  win.loadURL(SITE_URL);
}

async function manualUpdate() {
  win.setTitle('Güncellemeler kontrol ediliyor...');
  const m = await checkUpdates(() => {});
  if (m) current = m;
  win.setTitle(titleOf());
  win.reload();
}

// ---------- Başlangıç ----------
app.whenReady().then(async () => {
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(true));
  session.defaultSession.setPermissionCheckHandler(() => true);

  await createSplash();
  current = await checkUpdates(say);
  say('Başlatılıyor...', 100);
  createMain();
  win.once('ready-to-show', () => {});
  setTimeout(() => { if (splash && !splash.isDestroyed()) splash.close(); }, 600);
});

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => app.quit());
