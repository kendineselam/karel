@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Ilk kurulum yapiliyor, bekle...
  call npm install
)
call npm start
